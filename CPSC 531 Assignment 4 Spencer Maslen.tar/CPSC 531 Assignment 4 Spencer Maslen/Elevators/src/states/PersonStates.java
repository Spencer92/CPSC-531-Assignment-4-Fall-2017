package states;

public enum PersonStates 
{
	ARRIVING,
	IN_ELEVATOR,
	WAITING,
	WORKING,
	LEFT
}
