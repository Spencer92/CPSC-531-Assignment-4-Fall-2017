package states;

public enum ElevatorStates 
{
	MOVING_UP,MOVING_DOWN,IDLE
}

