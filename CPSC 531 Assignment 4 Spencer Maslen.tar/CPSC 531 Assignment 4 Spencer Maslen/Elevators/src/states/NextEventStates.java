package states;

public enum NextEventStates 
{
	PERSON_ARRIVAL,PERSON_DEPARTURE,ELEVATOR_DEPARTURE;
}
